import { Http } from '@angular/http';
import { Component } from '@angular/core';
import { NavController, PopoverController } from 'ionic-angular';

// search page
import { SearchPage } from '../search/search';
// storage
import { Storage } from '@ionic/storage';
// dropdown menu
import { DropdownHeaderPage } from '../dropdown-header/dropdown-header';
// cart page
import { CartPage } from '../cart/cart';
import { Observable } from 'rxjs/Observable';

@Component({selector: 'page-policy',templateUrl: 'policy.html',})
export class PolicyPage {

  public page:{} = {};
  errNoti: boolean = false;
  loadingFirst: boolean = false;
  constructor(public navCtrl: NavController,public storage: Storage,public popoverCtrl: PopoverController, private http: Http) {
    // storage product trong giỏ hàng
    http.get('https://suplo-app.herokuapp.com/dogo-app/pages/chinh-sach-dang-ky-tai-khoan')
    .map(res => res.json())
    .subscribe((data) =>{
       this.page = data.data.page;
       this.loadingFirst = true;
    },(err) => {
      this.errNoti = true;
    });
    // set timeout or error 3 phút
    setTimeout(() => {
      if (this.loadingFirst == false) {
        this.errNoti = true;
      }
    }, 180000);
  }

  // go to search page
  goSearch() {
    this.navCtrl.push(SearchPage);
  }
  // đến trang giỏ hàng
  gotoCart() {
    this.navCtrl.push(CartPage);
  }
  ionViewDidLoad() {
    // console.log('ionViewDidLoad PolicyPage');
  }

}
