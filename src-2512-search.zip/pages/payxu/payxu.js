var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CartPage } from '../cart/cart';
import { viewVariant } from '../product/product';
import { CoinService } from '../../services/coin.service';
/**
 * Generated class for the PayxuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var PayxuPage = /** @class */ (function () {
    function PayxuPage(navCtrl, navParams, cservice, cartPage, productPage) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.cservice = cservice;
        this.cartPage = cartPage;
        this.productPage = productPage;
        // 	this.cservice.getHandle('nap-xu', 1).subscribe((data) => {
        // this.items = data;
        // 	});
    }
    // // xem chi tiết sp
    // productTapped(qty) {
    // 	this.productPage.addCart(qty);
    //   this.cartPage.callCheckOut();
    // }
    PayxuPage.prototype.ionViewDidLoad = function () {
        // console.log('ionViewDidLoad PayxuPage');
    };
    PayxuPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-payxu',
            templateUrl: 'payxu.html',
            providers: [CoinService, CartPage, viewVariant]
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            CoinService,
            CartPage,
            viewVariant])
    ], PayxuPage);
    return PayxuPage;
}());
export { PayxuPage };
//# sourceMappingURL=payxu.js.map