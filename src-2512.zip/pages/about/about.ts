import { Component } from '@angular/core';
import { NavController, PopoverController } from 'ionic-angular';

// search page
import { SearchPage } from '../search/search';
// storage
import { Storage } from '@ionic/storage';
// dropdown menu
import { DropdownHeaderPage } from '../dropdown-header/dropdown-header';
// cart page
import { CartPage } from '../cart/cart';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {

public qtyItemCart: number = 0;
  constructor(public navCtrl: NavController,public storage: Storage,public popoverCtrl: PopoverController) {
    // storage product trong giỏ hàng
    this.storage.get('itemCarts').then((data) => {
      if (data == null) {
        this.qtyItemCart = 0;
      }else{
        this.qtyItemCart = data.length;
      }
    });
  }
  // go to search page
  goSearch() {
    this.navCtrl.push(SearchPage);
  }
  // đến trang giỏ hàng
  gotoCart() {
    this.navCtrl.push(CartPage);
  }
  // dropdown menu
  dropdownPopover() { 
    let popover = this.popoverCtrl.create(DropdownHeaderPage,{
      estest: '11'
    },{
      cssClass: 'dropdown-header'
    });
    popover.present();
  }
}
