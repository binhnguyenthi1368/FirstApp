import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
// storage
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
// Product page
import { ProductPage } from '../product/product';
import { IonicImageLoader, ImageLoader,ImgLoader, ImageLoaderConfig } from 'ionic-image-loader';
import { Globals } from '../../app/providers/globals';
import { ProductService } from '../../services/product.service';

/**
 * Generated class for the SearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',providers:[ProductService]
})
export class SearchPage {
  searchQuery: string = '';
  // ket qua tim kiem tra ve
  mentionWords: string[];
  results: any[];
  loadingFirst: boolean = true;
  public productResult;
  // timeout or empty
  notiTimeout: boolean = false;
  typeUser;
  isAgencyRegular: boolean = false;
  page = 1;
  totalPages = 1;


  constructor(public pservice: ProductService, public globals: Globals, public navCtrl: NavController, public navParams: NavParams,public storage: Storage,public http: Http) {
    // hien thi dai ly hoac ctv
    this.globals.typeUser.subscribe(data => {
      this.typeUser = data;
    });
    if(this.typeUser.indexOf('tổng đại lý') > -1){
      this.isAgencyRegular = true;
    }
  }
  // bo dau tieng viet
  removeSpecial(str) {
    str = str.toLowerCase();
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
    str = str.replace(/đ/g, 'd');
    // str = str.replace(/\W+/g, ' ');
    // str = str.replace(/\s/g, '-');
    return str;
  }
  eventHandler(keyCode, ev) {
    if (keyCode == 13) {
      this.loadingFirst = false;
      let val = ev.target.value;
      let newVal = this.removeSpecial(val);
      // get kết quả tìm kiếm
      this.pservice.gotoSearch(newVal, 1).subscribe((results) => {
        this.results = null;
        this.results = results['products'];
        this.totalPages = results['paginate'].pages;
        this.loadingFirst = true;
        this.autoLoadMore(newVal);
      },(err) => {
          this.notiTimeout = true;
        });
      // set timeout or error 5 phút
      setTimeout(() => {
        if (this.loadingFirst == false) {
          this.notiTimeout = true;
        }
      }, 300000);
    }
  }

  autoLoadMore(value){
    if (this.page < this.totalPages) {
      if(this.page < 5){
        setTimeout(()=>{
          this.page++;
          console.log(this.page);
          this.pservice.gotoSearch(value, this.page).subscribe((results) => {
            this.results = this.results.concat(results['products']);
            this.autoLoadMore(value);
          });
        }, 1000)
      }
    }
  }
  // click xem chi tiet sp
  productTapped($event, product) {
    console.log(product)
    var lengthPro = this.results.length;
    for (var i = 0; i <= lengthPro-1; i++) {
      if (this.results[i].handle == product) {
        break;
      }
    }
    // That's right, we're pushing to ourselves!
    this.productResult = this.results[i];
    // storage
    this.storage.get('seenProducts').then((data) => {
      if(data != null && data.length != 0) {
        let lengthArr: number;
        let checkDuplicate = 0;
        lengthArr = data.length;
        let compareID = this.productResult.id;
        for(var i = 0; i <= lengthArr-1; i++) {
          let checkID = data[i].id;
          if (checkID == compareID) {
            checkDuplicate++;
          }
        }
        if (checkDuplicate == 0) {
          if((this.productResult.isWholeSale && !this.isAgencyRegular)){
            this.productResult.price_format = '0₫';
            this.productResult.compare_at_price = 0;
            this.productResult.sale = '-0%';
          }
          data.push(this.productResult);
          this.storage.set('seenProducts', data);
        }
      } else {
        let arrID = [];
        if((this.productResult.isWholeSale && !this.isAgencyRegular)){
          this.productResult.price_format = '0₫';
          this.productResult.compare_at_price = 0;
          this.productResult.sale = '-0%';
        }
        arrID.push(this.productResult);
        this.storage.set('seenProducts', arrID);
      }
    });
    
    this.navCtrl.push(ProductPage, {
      product: product
      // product: this.products
    });
  }

  ionViewDidLoad() {
  }

}
