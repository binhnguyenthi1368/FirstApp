var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Directive, Input, ElementRef, Renderer } from '@angular/core';
import { Platform } from 'ionic-angular';
/**
 * Generated class for the HideHeaderDirective directive.
 *
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 */
var HideHeaderDirective = /** @class */ (function () {
    function HideHeaderDirective(element, renderer, platform) {
        this.element = element;
        this.renderer = renderer;
        this.platform = platform;
        // console.log('Hello HideHeaderDirective Directive');
    }
    HideHeaderDirective.prototype.ngOnInit = function () {
        this.headerHeight = this.header.clientHeight;
        this.scrollContent = this.element.nativeElement.getElementsByClassName("scroll-content")[0];
        this.menubar = this.element.nativeElement.getElementsByClassName("menu-bar")[0];
    };
    HideHeaderDirective.prototype.onContentScroll = function (event) {
        if (event.scrollTop > 61) {
            this.renderer.setElementStyle(this.header, 'webkitTransition', 'top 200ms');
            this.renderer.setElementStyle(this.header, "top", "-61px");
            this.renderer.setElementStyle(this.scrollContent, "margin-top", "0");
            this.renderer.setElementStyle(this.menubar, "position", "fixed");
            if (this.platform.is('ios')) {
                this.renderer.setElementStyle(this.menubar, "top", "20px");
            }
            else {
                this.renderer.setElementStyle(this.menubar, "top", "0");
            }
            this.renderer.setElementStyle(this.menubar, "z-index", "10");
        }
        else {
            this.renderer.setElementStyle(this.header, 'webkitTransition', 'top 0ms');
            this.renderer.setElementStyle(this.header, "top", "0");
            if (this.platform.is('ios')) {
                this.renderer.setElementStyle(this.scrollContent, "margin-top", "79px");
            }
            else {
                this.renderer.setElementStyle(this.scrollContent, "margin-top", "61px");
            }
            // this.renderer.setElementStyle(this.scrollContent, "margin-top", "61px");
            this.renderer.setElementStyle(this.menubar, "position", "unset");
            this.renderer.setElementStyle(this.menubar, "top", "unset");
        }
    };
    __decorate([
        Input("header"),
        __metadata("design:type", HTMLElement)
    ], HideHeaderDirective.prototype, "header", void 0);
    HideHeaderDirective = __decorate([
        Directive({
            selector: '[hide-header]',
            host: {
                '(ionScroll)': 'onContentScroll($event)'
            }
        }),
        __metadata("design:paramtypes", [ElementRef,
            Renderer,
            Platform])
    ], HideHeaderDirective);
    return HideHeaderDirective;
}());
export { HideHeaderDirective };
//# sourceMappingURL=hide-header.js.map