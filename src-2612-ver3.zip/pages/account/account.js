var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild } from '@angular/core';
import { Http } from '@angular/http';
import { Platform, ViewController, NavParams, Nav, AlertController, LoadingController, NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { PolicyPage } from '../policy/policy';
// import { ConferenceData } from '../../providers/conference-data';
//firebase login
import { AuthService } from '../../app/providers/auth.service';
import { CustomerService } from '../../services/customer.service';
// _JAVA_OPTIONS: -Xmx512M
var AccountPage = /** @class */ (function () {
    function AccountPage(platform, params, viewCtrl, storage, authService, cusService, alerCtrl, loadingCtrl, http, navCtrl) {
        this.platform = platform;
        this.params = params;
        this.viewCtrl = viewCtrl;
        this.storage = storage;
        this.authService = authService;
        this.cusService = cusService;
        this.alerCtrl = alerCtrl;
        this.loadingCtrl = loadingCtrl;
        this.http = http;
        this.navCtrl = navCtrl;
        this.checkgg = false;
        // loading first
        this.loadingAcc = false;
        // timeout or empty
        this.notiTimeout = false;
        this.notiTimeout1 = false;
        // check click btn
        this.clicked = false;
        this.agreed = false;
        // check phone
        this.phoneVali = false;
        this.phoneTypeVali = false;
        // check ma gioi thieu co thuoc
        this.codeVali = false;
        this.tabAcc = this.params.get('charNum');
        this.isAndroid = false;
        this.type = 'password';
        this.showPass = false;
        this.iconPass = 'eye-off';
        //firebase login testing
        this.login = { email: '', password: '' };
        this.submitted1 = false;
        this.submitted2 = false;
        this.signup = {
            first_name: '',
            email: '',
            phone: null,
            birthday: '',
            tags: '',
            invited_code: null,
            password: '',
            password_confirmation: '',
            accepts_marketing: true,
        };
    }
    AccountPage.prototype.dismiss = function () {
        this.viewCtrl.dismiss();
    };
    AccountPage.prototype.openPolicy = function () {
        this.navCtrl.push(PolicyPage);
    };
    AccountPage.prototype.showPassword = function () {
        this.showPass = !this.showPass;
        if (this.showPass) {
            this.type = 'text';
            this.iconPass = 'eye';
        }
        else {
            this.type = 'password';
            this.iconPass = 'eye-off';
        }
    };
    // noti state login/regis
    AccountPage.prototype.notiActive = function (noti) {
        var alert = this.alerCtrl.create({
            message: noti,
        });
        alert.present();
        if (alert.present()) {
            setTimeout(function () {
                alert.dismiss();
            }, 3000);
        }
    };
    AccountPage.prototype.loginFirebase = function (form) {
        var _this = this;
        this.clicked = true;
        this.loadingAcc = true;
        setTimeout(function () {
            _this.clicked = false;
        }, 3000);
        this.submitted1 = true;
        if (form.valid) {
            this.authService.emailLogin(this.login.email, this.login.password);
            setTimeout(function () {
                // sai pass
                if (_this.authService.test == 'The password is invalid or the user does not have a password.') {
                    _this.stateActive = 'Địa chỉ email hoặc mật khẩu không đúng!';
                    _this.notiActive(_this.stateActive);
                    _this.loadingAcc = false;
                }
                else {
                    // hợp lệ
                    if (_this.authService.test == 'ok') {
                        // check acc đại lý
                        _this.cusService.get(_this.login.email).subscribe(function (customer) {
                            // neu la dai ly nhung chua duoc xac nhan tai khoan => ko login
                            // tags customer phải có AGENCY, NOT-VERIFIED hoặc VERIFIED
                            if (customer.agency == 'AGENCY' && customer.agency_verified == 'NOT-VERIFIED') {
                                _this.logoutAgency();
                                _this.viewCtrl.dismiss();
                                _this.stateActive = 'Tài khoản của bạn đang chờ được xác nhận.';
                                _this.notiActive(_this.stateActive);
                            }
                            else {
                                if (customer.agency_verified == 'VERIFIED') {
                                    console.log(_this.login.email);
                                    // la dai ly da xac nhan acc va acc ctv 
                                    // lưu thông tin cần thiết (id, invitecode) của acc vào local storage để các page khác load tốt hơn
                                    // id
                                    _this.storage.set('customer_id', customer.id);
                                    // invite code
                                    _this.storage.set('invite_code', customer.invited_code);
                                    // sdt
                                    _this.storage.set('phone', customer.code);
                                    // lưu email
                                    _this.storage.set('infoAccount', _this.login.email);
                                    _this.email = _this.password = '';
                                    _this.viewCtrl.dismiss();
                                    _this.stateActive = 'Đăng nhập thành công!',
                                        _this.notiActive(_this.stateActive);
                                    _this.loadingAcc = false;
                                }
                                else {
                                    // neu chỉ có AGENCY thì sẽ tính tài khoản ko hợp lệ, ko cho login
                                    _this.logoutAgency();
                                    _this.viewCtrl.dismiss();
                                    _this.stateActive = 'Tài khoản của bạn xảy ra lỗi. Liên hệ Admin để khắc phục';
                                    _this.notiActive(_this.stateActive);
                                }
                            }
                        });
                    }
                    else {
                        // sai email
                        if (_this.authService.test == 'There is no user record corresponding to this identifier. The user may have been deleted.') {
                            _this.stateActive = 'Địa chỉ email không đúng. Tài khoản có thể đã bị xóa!';
                            _this.notiActive(_this.stateActive);
                            _this.loadingAcc = false;
                        }
                        else {
                            // lỗi khác
                            _this.stateActive = 'Kết nối chậm! Vui lòng kiểm tra lại kết nối Internet của bạn.';
                            _this.notiActive(_this.stateActive);
                            _this.loadingAcc = false;
                        }
                    }
                }
                // set timeout or error 3 phút
                setTimeout(function () {
                    if (_this.loadingAcc == false) {
                        _this.notiTimeout = true;
                    }
                }, 180000);
            }, 3000);
        }
        else {
            this.stateActive = 'Bạn vui lòng điền chính xác thông tin!';
            this.notiActive(this.stateActive);
            this.loadingAcc = false;
            this.clicked = false;
        }
    };
    AccountPage.prototype.logout = function () {
        var _this = this;
        this.authService.signOut();
        this.storage.get('infoAccount').then(function (data) {
            _this.storage.remove('infoAccount');
        });
        // id
        this.storage.get('customer_id').then(function (data) {
            _this.storage.remove('customer_id');
        });
        // invite code
        this.storage.get('invite_code').then(function (data) {
            _this.storage.remove('invite_code');
        });
        // sdt
        this.storage.get('phone').then(function (data) {
            _this.storage.remove('phone');
        });
        // check logout success?
        setTimeout(function () {
            _this.notiActive('Bạn đã đăng xuất!');
        }, 3000);
    };
    AccountPage.prototype.logoutAgency = function () {
        var _this = this;
        this.authService.signOut();
        this.storage.get('infoAccount').then(function (data) {
            _this.storage.remove('infoAccount');
        });
        // id
        this.storage.get('customer_id').then(function (data) {
            _this.storage.remove('customer_id');
        });
        // invite code
        this.storage.get('invite_code').then(function (data) {
            _this.storage.remove('invite_code');
        });
        // sdt
        this.storage.get('phone').then(function (data) {
            _this.storage.remove('phone');
        });
    };
    AccountPage.prototype.loginGoogle = function () {
        var _this = this;
        this.clicked = true;
        setTimeout(function () {
            _this.clicked = false;
        }, 3000);
        this.authService.googleLogin().then(function (data) {
            if (_this.authService.authState != null) {
                // gg login success
                console.log('state:  ' + _this.authService.authState);
                setTimeout(function () {
                    _this.viewCtrl.dismiss();
                    _this.notiActive('Đăng nhập thành công!');
                }, 3000);
                // luu email
                _this.storage.get('infoAccount').then(function (data) {
                    _this.storage.set('infoAccount', _this.authService.authState.email);
                    _this.loadingAcc = true;
                });
                // lưu thông tin cần thiết (id, invitecode) của acc vào local storage để các page khác load tốt hơn
                _this.cusService.get(_this.authService.authState.email).subscribe(function (customer) {
                    // id
                    _this.storage.get('customer_id').then(function (data) {
                        _this.storage.set('customer_id', customer.id);
                    });
                    // invite code
                    _this.storage.get('invite_code').then(function (data) {
                        _this.storage.set('invite_code', customer.invited_code);
                    });
                    // sdt
                    _this.storage.get('phone').then(function (data) {
                        _this.storage.set('phone', customer.code);
                    });
                });
                // set timeout or error 3 phút
                setTimeout(function () {
                    if (_this.loadingAcc == false) {
                        _this.notiTimeout = true;
                    }
                }, 180000);
            }
            else {
                _this.notiActive('Đăng nhập không thành công! Vui lòng kiểm tra lại kết nối');
            }
        });
    };
    AccountPage.prototype.onLogin = function (form) {
        this.submitted1 = true;
        if (form.valid) {
            // this.userData.login(this.login.username);
            // this.navCtrl.push(TabsPage);
        }
    };
    AccountPage.prototype.onSignup = function () {
        // this.navCtrl.push(SignupPage);
    };
    AccountPage.prototype.signupFirebase = function (form, readedPolicy) {
        var _this = this;
        this.clicked = true;
        this.loadingAcc = true;
        this.submitted2 = true;
        // check da doc dieu khoan
        if (readedPolicy == true) {
            // form hợp lệ
            if (form.valid) {
                if (this.signup.invited_code == null) {
                    this.signup.invited_code = 0;
                }
                if (this.signup.phone == null) {
                    this.signup.phone = 0;
                }
                // check ma da ton tai chua?
                this.http.get("https://suplo-app.herokuapp.com/dogo-app/customer-code-validate/" + this.signup.invited_code).map(function (res) { return res.json(); }).subscribe(function (data) {
                    if (data.data.metafields.length > 0) {
                        _this.codeVali = true;
                    }
                    else {
                        _this.codeVali = false;
                    }
                });
                // check sđt của acc mới đký đã đc dùng chưa?
                this.http.get("https://suplo-app.herokuapp.com/dogo-app/customer-code-validate/" + this.signup.phone).map(function (res) { return res.json(); }).subscribe(function (data) {
                    if (data.data.metafields.length == 0) {
                        _this.phoneVali = true;
                    }
                    else {
                        _this.phoneVali = false;
                    }
                });
                setTimeout(function () {
                    if (_this.codeVali == true && _this.phoneVali == true) {
                        console.log(_this.signup.email);
                        _this.authService.emailSignUp(_this.signup).then(function (data) {
                        });
                        // set timeout or error 3 phút
                        setTimeout(function () {
                            if (_this.loadingAcc == false) {
                                _this.notiTimeout1 = true;
                            }
                        }, 180000);
                        if (_this.authService.test == 'The email address is already in use by another account.') {
                            _this.stateActive = 'Địa chỉ email này đã được sử dụng bởi tài khoản khác!';
                            _this.notiActive(_this.stateActive);
                            _this.loadingAcc = false;
                            _this.clicked = false;
                        }
                        else {
                            if (_this.authService.test == 'ok') {
                                if (_this.signup.invited_code == parseInt('0913204678')) {
                                    _this.viewCtrl.dismiss();
                                    _this.loadingAcc = false;
                                    _this.clicked = false;
                                    _this.stateActive = 'Đăng ký tài khoản đại lý thành công! Tài khoản của bạn đang chờ được xác nhận.';
                                    _this.notiActive(_this.stateActive);
                                }
                                else {
                                    // la dai ly da xac nhan acc va acc ctv 
                                    // lưu thông tin cần thiết (id, invitecode) của acc vào local storage để các page khác load tốt hơn
                                    // lưu thông tin cần thiết (id, invitecode) của acc vào local storage để các page khác load tốt hơn
                                    _this.cusService.get(_this.signup.email).subscribe(function (customer) {
                                        // id
                                        _this.storage.get('customer_id').then(function (data) {
                                            _this.storage.set('customer_id', customer.id);
                                        });
                                        // invite code
                                        _this.storage.get('invite_code').then(function (data) {
                                            _this.storage.set('invite_code', customer.invited_code);
                                        });
                                        // sdt
                                        _this.storage.get('phone').then(function (data) {
                                            _this.storage.set('phone', customer.code);
                                        });
                                    });
                                    // luu email
                                    _this.storage.get('infoAccount').then(function (data) {
                                        _this.storage.set('infoAccount', _this.signup.email);
                                    });
                                    _this.viewCtrl.dismiss();
                                    _this.stateActive = 'Đăng ký thành công! Bạn đã đăng nhập.',
                                        _this.notiActive(_this.stateActive);
                                    _this.loadingAcc = false;
                                    _this.clicked = false;
                                }
                            }
                            else {
                                _this.stateActive = 'Kết nối chậm! Vui lòng kiểm tra lại kết nối Internet của bạn.';
                                _this.notiActive(_this.stateActive);
                                _this.loadingAcc = false;
                                _this.clicked = false;
                            }
                        }
                    }
                    else {
                        if (_this.codeVali == false && _this.phoneVali == true) {
                            // setTimeout(() => {
                            _this.stateActive = 'Mã giới thiệu không thuộc bất kỳ tài khoản nào.';
                            _this.notiActive(_this.stateActive);
                            _this.clicked = false;
                            // }, 4000);
                        }
                        else {
                            if (_this.codeVali == true && _this.phoneVali == false) {
                                // setTimeout(() => {
                                _this.stateActive = 'Số điện thoại ' + _this.signup.phone + ' đã được sử dụng bởi tài khoản khác.';
                                _this.notiActive(_this.stateActive);
                                _this.clicked = false;
                                // }, 4000);
                            }
                            else {
                                if (_this.codeVali == false && _this.phoneVali == false) {
                                    // setTimeout(() => {
                                    _this.stateActive = 'Thông tin điền vào không chính xác.';
                                    _this.notiActive(_this.stateActive);
                                    _this.clicked = false;
                                    // }, 4000);
                                }
                            }
                        }
                        _this.loadingAcc = false;
                    }
                }, 4000);
            }
            else {
                this.stateActive = 'Bạn vui lòng điền chính xác thông tin!';
                this.notiActive(this.stateActive);
                this.loadingAcc = false;
                this.clicked = false;
            }
        }
        else {
            this.stateActive = 'Bạn vui lòng đọc điều khoản và chính sách của chúng tôi!';
            this.notiActive(this.stateActive);
            this.loadingAcc = false;
            this.clicked = false;
        }
    };
    AccountPage.prototype.onRegis = function (form) {
        this.submitted2 = true;
        if (form.valid) {
            // this.userData.signup(this.signup.username);
            // this.navCtrl.push(TabsPage);
        }
    };
    AccountPage.prototype.doAgreed = function () {
        return !this.agreed;
    };
    __decorate([
        ViewChild(Nav),
        __metadata("design:type", Nav)
    ], AccountPage.prototype, "nav", void 0);
    AccountPage = __decorate([
        Component({ templateUrl: 'account.html', providers: [CustomerService] }),
        __metadata("design:paramtypes", [Platform,
            NavParams,
            ViewController,
            Storage,
            AuthService,
            CustomerService,
            AlertController,
            LoadingController,
            Http,
            NavController])
    ], AccountPage);
    return AccountPage;
}());
export { AccountPage };
//# sourceMappingURL=account.js.map