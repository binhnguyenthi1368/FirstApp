export interface Collection {
	id: number;
	title: string;
	banner: string;
}