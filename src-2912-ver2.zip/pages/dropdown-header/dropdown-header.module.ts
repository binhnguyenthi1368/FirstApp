import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DropdownHeaderPage } from './dropdown-header';

@NgModule({
  declarations: [
  ],
  imports: [
  ],
})
export class DropdownHeaderPageModule {}
