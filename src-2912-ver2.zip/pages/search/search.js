var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
// storage
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
// Product page
import { ProductPage } from '../product/product';
/**
 * Generated class for the SearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var SearchPage = /** @class */ (function () {
    function SearchPage(navCtrl, navParams, storage, http) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.storage = storage;
        this.http = http;
        this.searchQuery = '';
        this.loadingFirst = true;
        // timeout or empty
        this.notiTimeout = false;
    }
    // initializeItems() {
    //   this.mentionWords = [
    //     'ao len',
    //     'ao khoac',
    //     'nuoc giat',
    //     'laptop',
    //   ];
    // }
    // bo dau tieng viet
    SearchPage.prototype.removeSpecial = function (str) {
        str = str.toLowerCase();
        str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
        str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
        str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
        str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
        str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
        str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
        str = str.replace(/đ/g, 'd');
        // str = str.replace(/\W+/g, ' ');
        // str = str.replace(/\s/g, '-');
        return str;
    };
    SearchPage.prototype.eventHandler = function (keyCode, ev) {
        var _this = this;
        if (keyCode == 13) {
            this.loadingFirst = false;
            var val = ev.target.value;
            var newVal = this.removeSpecial(val);
            // get kết quả tìm kiếm
            this.http.get("https://suplo-app.herokuapp.com/dogo-app/search/" + newVal).map(function (res) { return res.json(); }).subscribe(function (data) {
                _this.results = data.data.products;
                _this.loadingFirst = true;
            });
            // set timeout or error 5 phút
            setTimeout(function () {
                if (_this.loadingFirst == false) {
                    _this.notiTimeout = true;
                }
            }, 300000);
        }
    };
    SearchPage.prototype.productTapped = function ($event, product) {
        var _this = this;
        console.log(product);
        var lengthPro = this.results.length;
        for (var i = 0; i <= lengthPro - 1; i++) {
            if (this.results[i].handle == product) {
                break;
            }
        }
        // That's right, we're pushing to ourselves!
        this.productResult = this.results[i];
        // storage
        this.storage.get('seenProducts').then(function (data) {
            if (data != null && data.length != 0) {
                var lengthArr = void 0;
                var checkDuplicate = 0;
                lengthArr = data.length;
                var compareID = _this.productResult.id;
                for (var i = 0; i <= lengthArr - 1; i++) {
                    var checkID = data[i].id;
                    if (checkID == compareID) {
                        checkDuplicate++;
                    }
                }
                if (checkDuplicate == 0) {
                    data.push(_this.productResult);
                    _this.storage.set('seenProducts', data);
                }
            }
            else {
                var arrID = [];
                arrID.push(_this.productResult);
                _this.storage.set('seenProducts', arrID);
            }
        });
        this.navCtrl.push(ProductPage, {
            product: product
            // product: this.products
        });
    };
    // getItems(ev: any) {
    //   // Reset items back to all of the items
    //   this.initializeItems();
    //   // set val to the value of the searchbar
    //   let val = ev.target.value;
    //   // if the value is an empty string don't filter the items
    //   if (val && val.trim() != '') {
    //     this.mentionWords = this.mentionWords.filter((item) => {
    //       return (item.toLowerCase().indexOf(val.toLowerCase()) > -1);
    //     })
    //   }else{
    //     // danh sach da tim kiem
    //     this.storage.get('searchs').then((data) => {
    //       this.mentionWords = data;
    //     });
    //   }
    // }
    SearchPage.prototype.ionViewDidLoad = function () {
    };
    SearchPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-search',
            templateUrl: 'search.html',
        }),
        __metadata("design:paramtypes", [NavController, NavParams, Storage, Http])
    ], SearchPage);
    return SearchPage;
}());
export { SearchPage };
//# sourceMappingURL=search.js.map