import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { UserPage } from './user';

@NgModule({
  declarations: [
    // UserPage,
    // OtherPage
  ],
  imports: [
    // IonicPageModule.forChild(UserPage),
  ],
  // entryComponents: [
  // 	OtherPage
  // ],
  // exports: [
  // 	OtherPage
  // ]
})
export class UserPageModule {}
