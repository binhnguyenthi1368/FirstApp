import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
/**
 * Generated class for the InfoXuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-info-xu',
  templateUrl: 'info-xu.html',
})
export class InfoXuPage {

  public page:{} = {};
  errNoti: boolean = false;
  loadingFirst: boolean = false;
  constructor(public navCtrl: NavController,public storage: Storage, private http: Http) {
    http.get('https://suplo-app.herokuapp.com/dogo-app/pages/huong-dan-nap-xu-rut-tien-app')
    .map(res => res.json())
    .subscribe((data) =>{
       this.page = data.data.page;
       this.loadingFirst = true;
    },(err) => {
      this.errNoti = true;
    });
    // set timeout or error 3 phút
    setTimeout(() => {
      if (this.loadingFirst == false) {
        this.errNoti = true;
      }
    }, 180000);
  }
  ionViewDidLoad() {}

}
