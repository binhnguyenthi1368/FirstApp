import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { PayxuPage } from './payxu';

@NgModule({
  declarations: [
    // PayxuPage,
  ],
  imports: [
    // IonicPageModule.forChild(PayxuPage),
  ],
})
export class PayxuPageModule {}
