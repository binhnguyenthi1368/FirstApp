import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { DetailOrderPage } from './detail-order';

@NgModule({
  declarations: [
    // DetailOrderPage,
  ],
  imports: [
    // IonicPageModule.forChild(DetailOrderPage),
  ],
})
export class DetailOrderPageModule {}
