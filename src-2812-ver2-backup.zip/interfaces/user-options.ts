
export interface UserOptions {
  username: string,
  password: string
}
export interface UserData {
	username: string,
	password: string,
	repassword: string,
	phone: number,
	email: string,
	address: string
}
