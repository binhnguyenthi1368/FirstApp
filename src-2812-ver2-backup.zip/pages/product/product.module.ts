import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { ProductPage } from './product';
// import { Routes, RouterModule } from '@angular/router';
@NgModule({
  declarations: [
    // ProductPage,
  ],
  
  imports: [
    // IonicPageModule.forChild(ProductPage),
   //  RouterModule.forRoot([
	  // { path: '', redirectTo: '#overview', pathMatch: 'full'},
	  // { path: 'overview', component: ProductPage},
	  // // { path: 'detail', component: ProductPage},
	  // { path: 'detail', loadChildren: 'product/product#detail'},

  	// ]),
  ],
})
export class ProductPageModule {}
