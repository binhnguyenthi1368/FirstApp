import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';

/**
 * Generated class for the DetailNotiPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail-noti',
  templateUrl: 'detail-noti.html',
})
export class DetailNotiPage {
  urlNoti;
  detailNoti;
  errNoti: boolean = false;
  loadingFirst: boolean = false;
  constructor(private httpClient: Http,public navCtrl: NavController, public navParams: NavParams) {
  	this.urlNoti = navParams.get('urlNoti');
  	this.httpClient.get(`https://suplo-app.herokuapp.com/dogo-app${this.urlNoti}`).map(res => res.json()).subscribe(article => {
      if(typeof article !== undefined && article !== null){
      	this.detailNoti = article.data.article;
    	 	this.loadingFirst = true;
  	  }else{
  	  	// this.loadingFirst = true;
  	  }
    },(err) => {
      this.errNoti = true;
    });
    // set timeout or error 3 phút
    setTimeout(() => {
      if (this.loadingFirst == false) {
        this.errNoti = true;
      }
    }, 180000);
  }

  ionViewDidLoad() {
    // console.log('ionViewDidLoad DetailNotiPage');
  }

}
