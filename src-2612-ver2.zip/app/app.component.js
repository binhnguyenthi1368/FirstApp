var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { HomePage } from './../pages/home/home';
import { Component, ViewChild } from '@angular/core';
import { Events, Nav, Platform, MenuController, ModalController, AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Storage } from '@ionic/storage';
import { AccountPage } from '../pages/account/account';
import { Http } from '@angular/http';
// policy page
import { PolicyPage } from '../pages/policy/policy';
// Notifications Model
import { NotificationsModel } from '../pages/notifications/notifications';
// user page
import { UserPage } from '../pages/user/user';
// order page
import { OrderPage } from '../pages/order/order';
// about page
import { AboutPage } from '../pages/about/about';
//commission page
import { CommissionPage } from '../pages/commission/commission';
//firebase login
import { AuthService } from './providers/auth.service';
import { ImageLoaderConfig } from 'ionic-image-loader';
var MyApp = /** @class */ (function () {
    function MyApp(platform, statusBar, splashScreen, modalCtrl, menu, authService, events, storage, http, alerCtrl, imageLoaderConfig) {
        var _this = this;
        this.platform = platform;
        this.statusBar = statusBar;
        this.splashScreen = splashScreen;
        this.modalCtrl = modalCtrl;
        this.menu = menu;
        this.authService = authService;
        this.events = events;
        this.storage = storage;
        this.http = http;
        this.alerCtrl = alerCtrl;
        this.imageLoaderConfig = imageLoaderConfig;
        this.rootPage = HomePage;
        // let status bar overlay webview
        this.statusBar.overlaysWebView(true);
        // set status bar to white
        this.initializeApp();
        this.pagesOther = [
            { title: 'Chính sách', component: PolicyPage, icon: 'help-buoy', color: 'blue-1' },
            { title: 'Về chúng tôi', component: AboutPage, icon: 'information-circle', color: 'pink-1' }
        ];
        this.http.get('https://suplo-app.herokuapp.com/dogo-app/settings').map(function (res) { return res.json(); }).subscribe(function (data) {
            _this.storage.set('home_settings', data.data.listcollections);
            // storage % đại lý
            _this.storage.set('dai_ly', data.data.percent_point.dai_ly / 100);
            // storage % thưởng nhi cap
            _this.storage.set('thuong_nhi_cap', data.data.percent_point.thuong_nhi_cap / 100);
            // storage % tich luy
            _this.storage.set('tich_luy', data.data.percent_point.tich_luy / 100);
            // storage % quy tu thien
            _this.storage.set('quy_tu_thien', data.data.percent_point.quy_tu_thien / 100);
        });
        // enable debug mode to get console logs and stuff
        imageLoaderConfig.enableDebugMode();
        // set a fallback url to use by default in case an image is not found
        imageLoaderConfig.setImageReturnType('base64');
        imageLoaderConfig.maxCacheSize = 2 * 1024 * 1024; // 2 MB
        imageLoaderConfig.maxCacheAge = 60 * 1000; // 1 minute
    }
    MyApp.prototype.gotoAccount = function () {
        this.nav.push(UserPage);
    };
    MyApp.prototype.gotoOrder = function () {
        this.nav.push(OrderPage);
    };
    MyApp.prototype.gotoCommission = function () {
        if (this.authService.authState != null) {
            this.nav.push(CommissionPage);
        }
        else {
            var modal = this.modalCtrl.create(AccountPage, { charNum: 'loginTab' });
            modal.present();
        }
    };
    // logout
    MyApp.prototype.logout = function () {
        var _this = this;
        this.authService.signOut();
        this.storage.get('infoAccount').then(function (data) {
            _this.storage.remove('infoAccount');
        });
        // check logout success?
        // setTimeout(() => {
        var alert = this.alerCtrl.create({
            message: 'Bạn đã đăng xuất!',
        });
        alert.present();
        if (alert.present()) {
            setTimeout(function () {
                alert.dismiss();
            }, 3000);
        }
        // }, 3000);
    };
    // login and regis
    MyApp.prototype.openModal = function (characterNum) {
        var modal = this.modalCtrl.create(AccountPage, characterNum);
        modal.present();
    };
    // go to user page or other page
    MyApp.prototype.gotoPage = function (page, check) {
        this.nav.push(page, {
            check: check
        });
    };
    // check login: if login go to oder page else go to login page
    MyApp.prototype.checkLogin = function (charLogin) {
        if (this.authService.authState != null) {
            this.nav.push(OrderPage);
        }
        else {
            var modal = this.modalCtrl.create(AccountPage, charLogin);
            modal.present();
        }
    };
    MyApp.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    // hien thi modal notification
    MyApp.prototype.showNoti = function (id) {
        var modal = this.modalCtrl.create(NotificationsModel, id);
        modal.present();
    };
    // go to page
    MyApp.prototype.openPage = function (page) {
        // page home, all collections
        this.nav.push(page.component);
    };
    // goto home page
    MyApp.prototype.openHome = function () {
        // page home, all collections
        this.nav.popToRoot();
    };
    __decorate([
        ViewChild(Nav),
        __metadata("design:type", Nav)
    ], MyApp.prototype, "nav", void 0);
    MyApp = __decorate([
        Component({ templateUrl: 'app.html' }),
        __metadata("design:paramtypes", [Platform,
            StatusBar,
            SplashScreen,
            ModalController,
            MenuController,
            AuthService,
            Events,
            Storage,
            Http,
            AlertController,
            ImageLoaderConfig])
    ], MyApp);
    return MyApp;
}());
export { MyApp };
//# sourceMappingURL=app.component.js.map