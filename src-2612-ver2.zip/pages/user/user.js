var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
// storage
import { Storage } from '@ionic/storage';
// other page
import { OtherPage } from '../other/other';
// customer service
import { CustomerService } from '../../services/customer.service';
/**
 * Generated class for the UserPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var UserPage = /** @class */ (function () {
    function UserPage(navCtrl, navParams, toastCtrl, storage, cusService) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.toastCtrl = toastCtrl;
        this.storage = storage;
        this.cusService = cusService;
        this.loadingFirst = false;
        this.accCode = '2';
        // timeout or empty
        this.notiTimeout = false;
        // info account
        this.storage.get('infoAccount').then(function (data) {
            _this.cusService.get(data).subscribe(function (customer) {
                _this.infoAccount = customer;
                // ma code ca nhan
                // this.cusService.getCode(customer.id).subscribe((code) => {
                //   this.accCode = code.code;
                //   console.log('this code  '+ this.accCode);
                // });
                if (customer.birthday != null) {
                    _this.birthday = customer.birthday.split('T', 2);
                    _this.birthday = _this.birthday[0].split('-', 3);
                    _this.year = _this.birthday[0];
                    _this.month = _this.birthday[1];
                    _this.day = _this.birthday[2];
                }
                _this.gender = customer.gender;
                _this.loadingFirst = true;
            });
        });
        // set timeout or error 5 phút
        setTimeout(function () {
            if (_this.loadingFirst == false) {
                _this.notiTimeout = true;
            }
        }, 300000);
    }
    UserPage.prototype.showCodeUser = function () {
        var usedCode;
        if (this.accCode != '0') {
            usedCode = 'Bạn đã sử dụng mã giới thiệu: ' + this.accCode;
        }
        else {
            usedCode = 'Bạn chưa sử dụng mã giới thiệu';
        }
        var toast = this.toastCtrl.create({
            message: usedCode,
            showCloseButton: true,
            closeButtonText: 'Ok'
        });
        toast.present();
        if (toast.present()) {
            setTimeout(function () {
                toast.dismiss();
            }, 3000);
        }
    };
    UserPage.prototype.showYourCode = function (event, check, code) {
        this.navCtrl.push(OtherPage, {
            check: check,
            code: code
        });
    };
    UserPage.prototype.ionViewDidLoad = function () {
    };
    UserPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-user',
            templateUrl: 'user.html',
        }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            ToastController,
            Storage,
            CustomerService])
    ], UserPage);
    return UserPage;
}());
export { UserPage };
//# sourceMappingURL=user.js.map