import { NgModule } from '@angular/core';
import { HideHeaderDirective } from './hide-header/hide-header';
@NgModule({
})
export class DirectivesModule {}
