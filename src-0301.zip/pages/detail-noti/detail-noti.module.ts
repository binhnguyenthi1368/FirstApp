import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { DetailNotiPage } from './detail-noti';

@NgModule({
  declarations: [
    // DetailNotiPage,
  ],
  imports: [
    // IonicPageModule.forChild(DetailNotiPage),
  ],
})
export class DetailNotiPageModule {}
