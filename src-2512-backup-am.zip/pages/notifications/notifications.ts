import { Http } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Component} from '@angular/core';
import { Platform, ViewController, NavParams, ModalController, NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { NotificationsService } from '../../services/notifications.service';
import { Observable } from 'rxjs/Observable';
import { DetailNotiPage } from '../detail-noti/detail-noti';
import { Globals } from './../../app/providers/globals';

// import { FCM } from '@ionic-native/fcm';

@Component({templateUrl: 'notifications.html'})
export class NotificationsModel {
  notis: any[] = [];
  counts: number = 0;
  notisOber: Observable<any>;
  errNoti: boolean = false;
  loadingFirst: boolean = false;
  constructor(
    public platform: Platform,
    public params: NavParams,
    public viewCtrl: ViewController,  
    private notiService: NotificationsService,
    private storage: Storage,
    private httpClient: Http,
    private modalCtrl: ModalController,
    public navCtrl: NavController,
    private globals: Globals
    // private fcm: FCM
  ){
    // this.fcmPlugin();
    this.storage.get('notifications').then((notis) => {
      if(typeof notis !== undefined && notis !== null){
        // this.notis = notis;
        this.httpClient.get('https://suplo-app.herokuapp.com/dogo-app/blogs/dogo-app-thong-bao').map(res => res.json()).subscribe(blog => {
          if(typeof blog !== undefined && blog !== null){
            if (blog.data.articles !== this.notis) {
              this.notis = blog.data.articles;
            }
          }else{
            this.notis = notis;
          }
          this.loadingFirst = true;
          this.storage.set('notifications', this.notis);
          this.storage.get('notiseen').then((notiseen)=>{
            if(typeof notiseen !== "undefined" && notiseen !== null){
              var count = this.notis.length - notiseen.length;
              this.notis.forEach(article => {
                if(notiseen.some(x => x === article.url)){
                  article.seen = true;
                }
              })
              this.globals.setNotiCounts(count);
            }else{
              this.globals.setNotiCounts(this.notis.length);
            }
          })
        },(err) => {
          this.errNoti = true;
        });
      }else{
        this.httpClient.get('https://suplo-app.herokuapp.com/dogo-app/blogs/dogo-app-thong-bao').map(res => res.json()).subscribe(blog => {
          if(typeof blog !== undefined && blog !== null){
            this.notis = blog.data.articles;
            this.storage.set('notifications', this.notis);
          }else{
            this.notis = [];
            this.storage.set('notifications', []);
          }
          this.globals.setNotiCounts(this.notis.length);
          this.loadingFirst = true;
        },(err) => {
          this.errNoti = true;
        });
      }
    });
  }
  viewNotification(noti: any){
    var url = noti.url;
    noti.seen = true;
    if(typeof url !== undefined && url !== ""){
      this.navCtrl.push(DetailNotiPage, {
        urlNoti: url
      });
      this.storage.get('notiseen').then((notiseen)=>{
        console.log(notiseen);
        //viewd = {["handle"]};
        if(typeof notiseen !== "undefined" && notiseen !== null){
          console.log(notiseen.some(x => x === url))
          if(!notiseen.some(x => x === url)){
              notiseen.push(url);
              this.storage.set('notiseen', notiseen);
          };
        }else{
          notiseen = [];
          notiseen.push(url);
          this.storage.set('notiseen', notiseen);
        }
        var count = this.notis.length - notiseen.length;
        this.globals.setNotiCounts(count);
      })
    }
  }
  removeNotification(id) {
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }
}