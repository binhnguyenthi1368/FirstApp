import { NgModule } from '@angular/core';
// import { IonicPageModule } from 'ionic-angular';
// import { InfoXuPage } from './info-xu';

@NgModule({
  declarations: [
    // InfoXuPage,
  ],
  imports: [
    // IonicPageModule.forChild(InfoXuPage),
  ],
})
export class InfoXuPageModule {}
