var Profile = /** @class */ (function () {
    function Profile(app, account) {
        this.app = app;
        this.account = account;
    }
    Profile.prototype.isAgency = function () {
        if (this.account.tags.indexOf('AGENCY') !== -1) {
            return true;
        }
        return false;
    };
    Profile.prototype.isAgencyRegular = function () {
        if (this.account.tags.indexOf('AGENCY-REGULAR') !== -1) {
            return true;
        }
        return false;
    };
    Profile.prototype.isMember = function () {
    };
    return Profile;
}());
export { Profile };
//# sourceMappingURL=profiles.js.map