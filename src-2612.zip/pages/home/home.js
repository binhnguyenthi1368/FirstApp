var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild, Pipe } from '@angular/core';
import { Nav, NavParams, NavController, ModalController } from 'ionic-angular';
import { Http } from '@angular/http';
// storage
import { Globals } from './../../app/providers/globals';
import { Storage } from '@ionic/storage';
// collection page
import { CollectionsPage } from '../collections/collections';
// Notifications Model
import { NotificationsModel } from '../notifications/notifications';
import { SearchPage } from '../search/search';
// cart page
import { CartPage } from '../cart/cart';
import { NotificationsService } from '../../services/notifications.service';
import { Platform } from 'ionic-angular/platform/platform';
import { ImageLoaderConfig } from 'ionic-image-loader';
// tinh chieu cao cho collections level 2
var RoundPipe = /** @class */ (function () {
    function RoundPipe() {
    }
    /**
     * @param value
     * @returns {number}
     */
    RoundPipe.prototype.transform = function (value) {
        var heightItem = Math.ceil(value / 3);
        return heightItem * 53;
    };
    RoundPipe = __decorate([
        Pipe({ name: 'ceil' })
    ], RoundPipe);
    return RoundPipe;
}());
export { RoundPipe };
var HomePage = /** @class */ (function () {
    function HomePage(navCtrl, navParams, modalCtrl, http, storage, globals, notiService, platform, imageLoaderConfig) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.http = http;
        this.storage = storage;
        this.globals = globals;
        this.notiService = notiService;
        this.platform = platform;
        this.imageLoaderConfig = imageLoaderConfig;
        this.qtyItemCart = 0;
        this.notiCounts = 0;
        // settings
        this.settings = [];
        // loading first
        this.loadingFirst = true;
        // timeout or empty
        this.notiTimeout = true;
        imageLoaderConfig.enableSpinner(true);
        // storage noti
        this.globals.notiCounts.subscribe(function (data) {
            _this.notiCounts = data;
        });
        // so thong bao
        this.storage.get('notifications').then(function (data) {
            if (data !== null)
                _this.notiCounts = data.length;
        });
        this.globals.setNotiCounts(this.notiCounts);
        this.globals.notiCounts.subscribe(function (data) {
            _this.notiCounts = data;
        });
        this.storage.get('itemCarts').then(function (data) {
            if (data == null) {
                _this.qtyItemCart = 0;
            }
            else {
                _this.qtyItemCart = data.length;
            }
            _this.globals.setCartCounts(_this.qtyItemCart);
            _this.globals.cartCounts.subscribe(function (data) {
                _this.qtyItemCart = data;
            });
        });
        this.selectedIndex = -1;
        // get menu
        this.storage.get('home_settings').then(function (settings) {
            console.log(settings);
            if (settings !== null) {
                _this.settings = settings;
            }
            else {
                _this.http.get('https://suplo-app.herokuapp.com/dogo-app/settings').map(function (res) { return res.json(); }).subscribe(function (data) {
                    console.log(data);
                    _this.settings = data.data.listcollections;
                    _this.loadingFirst = true;
                    // storage % đại lý
                    _this.storage.set('dai_ly', data.data.percent_point.dai_ly / 100);
                    // storage % thưởng nhi cap
                    _this.storage.set('thuong_nhi_cap', data.data.percent_point.thuong_nhi_cap / 100);
                    // storage % tich luy
                    _this.storage.set('tich_luy', data.data.percent_point.tich_luy / 100);
                    // storage % quy tu thien
                    _this.storage.set('quy_tu_thien', data.data.percent_point.quy_tu_thien / 100);
                });
            }
        });
        // set timeout or error 5 phút
        setTimeout(function () {
            if (_this.loadingFirst == false) {
                _this.notiTimeout = true;
            }
        }, 300000);
    }
    // show page notification
    HomePage.prototype.showNoti = function (id) {
        var modal = this.modalCtrl.create(NotificationsModel, id);
        modal.present();
    };
    // go to search page
    HomePage.prototype.goSearch = function () {
        this.navCtrl.push(SearchPage);
    };
    // đến trang giỏ hàng
    HomePage.prototype.gotoCart = function () {
        this.navCtrl.push(CartPage);
    };
    // đến trang collection level 2
    HomePage.prototype.openCollection = function (event, collectionID, collectionTitle) {
        this.navCtrl.push(CollectionsPage, {
            collectionID: collectionID,
            collectionTitle: collectionTitle
        });
    };
    // Collapse collection
    HomePage.prototype.iconChange = function (index) {
        if (this.selectedIndex == index) {
            this.selectedIndex = -1;
        }
        else {
            this.selectedIndex = index;
        }
    };
    HomePage.prototype.onImageLoad = function (ionicImageLoader) {
        console.log('loaded');
    };
    __decorate([
        ViewChild(Nav),
        __metadata("design:type", Nav)
    ], HomePage.prototype, "nav", void 0);
    HomePage = __decorate([
        Component({ selector: 'page-home', templateUrl: 'home.html' }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            ModalController,
            Http,
            Storage,
            Globals,
            NotificationsService,
            Platform,
            ImageLoaderConfig])
    ], HomePage);
    return HomePage;
}());
export { HomePage };
//# sourceMappingURL=home.js.map