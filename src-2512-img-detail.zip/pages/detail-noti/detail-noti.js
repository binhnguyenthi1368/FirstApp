var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
/**
 * Generated class for the DetailNotiPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var DetailNotiPage = /** @class */ (function () {
    function DetailNotiPage(httpClient, navCtrl, navParams) {
        var _this = this;
        this.httpClient = httpClient;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.errNoti = false;
        this.loadingFirst = false;
        this.urlNoti = navParams.get('urlNoti');
        this.httpClient.get("https://suplo-app.herokuapp.com/dogo-app" + this.urlNoti).map(function (res) { return res.json(); }).subscribe(function (article) {
            if (typeof article !== undefined && article !== null) {
                _this.detailNoti = article.data.article;
                _this.loadingFirst = true;
            }
            else {
                // this.loadingFirst = true;
            }
        });
        // set timeout or error 3 phút
        setTimeout(function () {
            if (_this.loadingFirst == false) {
                _this.errNoti = true;
            }
        }, 180000);
    }
    DetailNotiPage.prototype.ionViewDidLoad = function () {
        // console.log('ionViewDidLoad DetailNotiPage');
    };
    DetailNotiPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-detail-noti',
            templateUrl: 'detail-noti.html',
        }),
        __metadata("design:paramtypes", [Http, NavController, NavParams])
    ], DetailNotiPage);
    return DetailNotiPage;
}());
export { DetailNotiPage };
//# sourceMappingURL=detail-noti.js.map