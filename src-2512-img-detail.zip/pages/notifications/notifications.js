var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Http } from '@angular/http';
import { Component } from '@angular/core';
import { Platform, ViewController, NavParams, ModalController, NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { NotificationsService } from '../../services/notifications.service';
import { DetailNotiPage } from '../detail-noti/detail-noti';
// import { FCM } from '@ionic-native/fcm';
var NotificationsModel = /** @class */ (function () {
    function NotificationsModel(platform, params, viewCtrl, notiService, storage, httpClient, modalCtrl, navCtrl) {
        var _this = this;
        this.platform = platform;
        this.params = params;
        this.viewCtrl = viewCtrl;
        this.notiService = notiService;
        this.storage = storage;
        this.httpClient = httpClient;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.notis = [];
        this.counts = 0;
        this.errNoti = false;
        this.loadingFirst = false;
        // this.fcmPlugin();
        this.storage.get('notifications').then(function (notis) {
            if (typeof notis !== undefined && notis !== null) {
                // this.notis = notis;
                _this.httpClient.get('https://suplo-app.herokuapp.com/dogo-app/blogs/dogo-app-thong-bao').map(function (res) { return res.json(); }).subscribe(function (blog) {
                    if (typeof blog !== undefined && blog !== null) {
                        if (blog.data.articles !== _this.notis) {
                            _this.notis = blog.data.articles;
                        }
                    }
                    else {
                        _this.notis = notis;
                    }
                    _this.loadingFirst = true;
                    console.log('has :' + _this.notis.length);
                    _this.storage.set('notifications', _this.notis);
                    _this.notiService.updateCount(_this.notis);
                });
            }
            else {
                _this.httpClient.get('https://suplo-app.herokuapp.com/dogo-app/blogs/dogo-app-thong-bao').map(function (res) { return res.json(); }).subscribe(function (blog) {
                    if (typeof blog !== undefined && blog !== null) {
                        _this.notis = blog.data.articles;
                        _this.storage.set('notifications', _this.notis);
                    }
                    else {
                        _this.errNoti = true;
                        _this.notis = [];
                        _this.storage.set('notifications', []);
                    }
                    _this.loadingFirst = true;
                    _this.notiService.updateCount(_this.notis);
                    console.log('null :' + _this.notis.length);
                });
            }
        });
        // this.httpClient.get('https://suplo-app.herokuapp.com/dogo-app/blogs/dogo-app-thong-bao').map(res => res.json()).subscribe(blog => {
        //   if(typeof blog !== undefined && blog !== null){
        //     this.notis = blog.data.articles;
        //   }else{
        //     this.errNoti = true;
        //   }
        // });
    }
    NotificationsModel.prototype.viewNotification = function (url) {
        if (typeof url !== undefined && url !== "") {
            this.navCtrl.push(DetailNotiPage, {
                urlNoti: url
            });
        }
    };
    NotificationsModel.prototype.removeNotification = function (id) {
    };
    NotificationsModel.prototype.dismiss = function () {
        this.viewCtrl.dismiss();
    };
    NotificationsModel = __decorate([
        Component({ templateUrl: 'notifications.html' }),
        __metadata("design:paramtypes", [Platform,
            NavParams,
            ViewController,
            NotificationsService,
            Storage,
            Http,
            ModalController,
            NavController])
    ], NotificationsModel);
    return NotificationsModel;
}());
export { NotificationsModel };
//# sourceMappingURL=notifications.js.map