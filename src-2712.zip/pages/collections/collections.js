var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, PopoverController } from 'ionic-angular';
import { Http } from '@angular/http';
// storage
import { Storage } from '@ionic/storage';
// import { CurrencyPipe } from '@angular/common';
// cart page
import { CartPage } from '../cart/cart';
// search page
import { SearchPage } from '../search/search';
// Product page
import { ProductPage } from '../product/product';
import { ProductService } from '../../services/product.service';
import { DropdownHeaderPage } from '../dropdown-header/dropdown-header';
import { Globals } from '../../app/providers/globals';
var CollectionsPage = /** @class */ (function () {
    function CollectionsPage(navCtrl, navParams, modalCtrl, http, pservice, globals, storage, popoverCtrl) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.modalCtrl = modalCtrl;
        this.http = http;
        this.pservice = pservice;
        this.globals = globals;
        this.storage = storage;
        this.popoverCtrl = popoverCtrl;
        // @ViewChild(Nav) nav: Nav;
        // loading first
        this.loadingFirst = false;
        this.product = 0;
        this.products = [];
        // test infinite scroll
        this.items = [];
        this.page = 1;
        this.loading = true;
        this.totalPages = 1;
        // timeout or empty
        this.notiTimeout = false;
        this.qtyItemCart = 0;
        // storage: lay so product dang co trong giỏ hàng
        this.storage.get('itemCarts').then(function (data) {
            if (data == null) {
                _this.qtyItemCart = 0;
            }
            else {
                _this.qtyItemCart = data.length;
            }
            _this.globals.setCartCounts(_this.qtyItemCart);
            _this.globals.cartCounts.subscribe(function (data) {
                _this.qtyItemCart = data;
            });
        });
        // get collection_id, collection_title
        this.selectedCollection = navParams.get('collectionID');
        this.titleCollection = navParams.get('collectionTitle');
        // get product by collection_handle
        this.pservice.getHandle(this.selectedCollection, 1).subscribe(function (products) {
            _this.products = products;
            _this.loadingFirst = true;
        });
        // lay so trang cua collection
        this.http.get("https://suplo-app.herokuapp.com/dogo-app/collections/" + this.selectedCollection + "/1").map(function (res) { return res.json(); }).subscribe(function (data) {
            _this.totalPages = data.data.paginate.pages;
        });
        // set timeout or error 5 phút
        setTimeout(function () {
            if (_this.loadingFirst == false) {
                _this.notiTimeout = true;
            }
        }, 300000);
    }
    CollectionsPage_1 = CollectionsPage;
    // dropdown menu
    CollectionsPage.prototype.dropdownPopover = function () {
        var popover = this.popoverCtrl.create(DropdownHeaderPage, {
            estest: '11'
        }, {
            cssClass: 'dropdown-header'
        });
        popover.present();
    };
    // đến trang giỏ hàng
    CollectionsPage.prototype.gotoCart = function () {
        this.navCtrl.push(CartPage);
    };
    // go to search page
    CollectionsPage.prototype.goSearch = function () {
        this.navCtrl.push(SearchPage);
    };
    // test infinite scroll
    CollectionsPage.prototype.doInfinite = function (infiniteScroll) {
        var _this = this;
        if (this.page < this.totalPages) {
            this.loading = true;
            setTimeout(function () {
                _this.page++;
                _this.pservice.getHandle(_this.selectedCollection, _this.page).subscribe(function (products) {
                    _this.items.push(products);
                });
                infiniteScroll.complete();
            }, 500);
        }
        else {
            this.loading = false;
        }
    };
    CollectionsPage.prototype.openCollection = function (event, collectionID, collectionTitle) {
        this.navCtrl.push(CollectionsPage_1, {
            collectionID: collectionID,
            collectionTitle: collectionTitle
        });
    };
    // xem chi tiết sp
    CollectionsPage.prototype.productTapped = function ($event, product) {
        var _this = this;
        var lengthPro = this.products.length;
        for (var i = 0; i <= lengthPro - 1; i++) {
            if (this.products[i].handle == product) {
                break;
            }
        }
        // That's right, we're pushing to ourselves!
        this.productSelected = this.products[i];
        // storage
        this.storage.get('seenProducts').then(function (data) {
            if (data != null && data.length != 0) {
                var lengthArr = void 0;
                var checkDuplicate = 0;
                lengthArr = data.length;
                var compareID = _this.productSelected.id;
                for (var i = 0; i <= lengthArr - 1; i++) {
                    var checkID = data[i].id;
                    if (checkID == compareID) {
                        checkDuplicate++;
                    }
                }
                if (checkDuplicate == 0) {
                    data.push(_this.productSelected);
                    _this.storage.set('seenProducts', data);
                }
            }
            else {
                var arrID = [];
                arrID.push(_this.productSelected);
                _this.storage.set('seenProducts', arrID);
            }
        });
        this.navCtrl.push(ProductPage, {
            product: product
            // product: this.products
        });
    };
    CollectionsPage.prototype.ionViewDidLoad = function () {
    };
    CollectionsPage = CollectionsPage_1 = __decorate([
        Component({ selector: 'page-collections', templateUrl: 'collections.html', providers: [ProductService] }),
        __metadata("design:paramtypes", [NavController,
            NavParams,
            ModalController,
            Http,
            ProductService,
            Globals,
            Storage,
            PopoverController])
    ], CollectionsPage);
    return CollectionsPage;
    var CollectionsPage_1;
}());
export { CollectionsPage };
//# sourceMappingURL=collections.js.map